package BE_SellerVo;

public class BE_ChannelVo {
		int chnum;
		int snum;
		public int getChnum() {
			return chnum;
		}
		public void setChnum(int chnum) {
			this.chnum = chnum;
		}
		public int getSnum() {
			return snum;
		}
		public void setSnum(int snum) {
			this.snum = snum;
		}
		public BE_ChannelVo(int chnum, int snum) {
			super();
			this.chnum = chnum;
			this.snum = snum;
		}
		public BE_ChannelVo() {
			super();
			// TODO Auto-generated constructor stub
		}
	
		
}
