package BE_ShoppingVo;

public class BE_GbuyVo {
	int pNum;
	int gNum;
	public int getpNum() {
		return pNum;
	}
	public void setpNum(int pNum) {
		this.pNum = pNum;
	}
	public int getgNum() {
		return gNum;
	}
	public void setgNum(int gNum) {
		this.gNum = gNum;
	}
	public BE_GbuyVo(int pNum, int gNum) {
		super();
		this.pNum = pNum;
		this.gNum = gNum;
	}
	public BE_GbuyVo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
