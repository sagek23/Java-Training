package BE_ShoppingVo;

public class BE_GroupVo {
	int gNum;
	int pNum;
	public int getgNum() {
		return gNum;
	}
	public void setgNum(int gNum) {
		this.gNum = gNum;
	}
	public int getpNum() {
		return pNum;
	}
	public void setpNum(int pNum) {
		this.pNum = pNum;
	}
	public BE_GroupVo(int gNum, int pNum) {
		super();
		this.gNum = gNum;
		this.pNum = pNum;
	}
	public BE_GroupVo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
